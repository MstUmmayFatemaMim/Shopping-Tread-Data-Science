TextData <- read.csv("F:/AIUB  All Sem/Aiub Sem - 10/INTRODUCTION TO DATA SCIENCE [A]/Mid/Lab/Project/Project_2/Scraped_Data.csv", header = TRUE, sep = ",")
print(TextData)
contractions <- c(
  "can't" = "cannot",
  "won't" = "will not",
  "don't" = "do not",
  "didn't" = "did not",
  "isn't" = "is not",
  "aren't" = "are not",
  "wasn't" = "was not",
  "weren't" = "were not",
  "hasn't" = "has not",
  "haven't" = "have not",
  "he's" = "he is",
  "she's" = "she is",
  "it’s" = "it is",
  "they’re" = "they are",
  "you’re" = "you are",
  "i'm" = "i am",
  "we're" = "we are",
  "that's" = "that is",
  "what's" = "what is",
  "who's" = "who is",
  "you’ll" = "you will"
)
expand_contractions <- function(text, contractions) {
  for (contraction in names(contractions)) {
    text <- gsub(paste0("\\b", contraction, "\\b"), contractions[contraction], text, ignore.case = TRUE)
  }
  return(text)
}
TextData$Data <- sapply(TextData$Data, expand_contractions, contractions = contractions)
print(TextData)
TextData$Data <- tolower(TextData$Data)
TextData
library(stringr)  
remove_punctuation_special_characters <- function(text) {
  gsub("[^a-zA-Z0-9[:space:]]", "", text)
}
TextData$Data <- sapply(TextData$Data, remove_punctuation_special_characters)
print(TextData)
TextData$Data <- gsub("[0-9]", "", TextData$Data)
TextData$Data <- gsub("<[^>]*>", "", TextData$Data)
print(TextData)
remove_emojis_regex <- function(text) {
  gsub("[\U0001F600-\U0001F64F]|[\U0001F300-\U0001F5FF]|[\U0001F680-\U0001F6FF]|[\U0001F1E0-\U0001F1FF]", "", text, perl = TRUE)
}
TextData$Data <- sapply(TextData$Data, remove_emojis_regex)
install.packages("tokenizers")
library(tokenizers)
tokenize_text <- function(text) {
  unlist(tokenize_words(text, lowercase = FALSE))
}
TextData$Tokens <- sapply(TextData$Data, tokenize_text)
print(TextData)


install.packages("tm")
library(tm)
stop_words <- stopwords("en")
remove_stop_words <- function(tokens, stop_words) {
  tokens <- tokens[!tokens %in% stop_words]
  return(tokens)
}
TextData$CleanedTokens <- lapply(TextData$Tokens, remove_stop_words, stop_words = stop_words)
print(TextData)

install.packages("SnowballC")
library(SnowballC)
stem_tokens <- function(tokens) {
  sapply(tokens, wordStem, language = "en")
}
TextData$StemmedTokens <- lapply(TextData$CleanedTokens, stem_tokens)
print(TextData)

install.packages("textstem")
library(textstem)
lemmatize_tokens <- function(tokens) {
  lemmatize_words(tokens)
}
TextData$LemmatizedTokens <- lapply(TextData$CleanedTokens, lemmatize_tokens)
print(TextData)

install.packages("hunspell")
library(hunspell)
check_and_correct_spelling <- function(tokens) {
  corrected_tokens <- hunspell_check(tokens)  
  corrected_tokens <- sapply(corrected_tokens, function(x) if(length(x) > 0) x[1] else "")  
  return(corrected_tokens)
}
TextData$CorrectedTokens <- lapply(TextData$LemmatizedTokens, check_and_correct_spelling)
print(TextData)

install.packages("openxlsx")
library(openxlsx)
write.xlsx(TextData, "F:/AIUB  All Sem/Aiub Sem - 10/INTRODUCTION TO DATA SCIENCE [A]/Mid/Lab/Project/Project_2/Preprocessed_Dataset.xlsx", rowNames = FALSE)